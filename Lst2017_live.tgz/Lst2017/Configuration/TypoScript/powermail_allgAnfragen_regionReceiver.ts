#Wien = 9, Graz = 10, Innsbruck = 11, Mönchengladbach = 12, Hamburg = 13, Pockau = 14, Intern = 15, noRegion = 17, Augsburg = 44


#Wien = 9
[regionSelected("9")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_wien}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_wien}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_wien}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_wien}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_wien}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_wien}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_wien}
[end]

[siteLanguage("languageId") == 1 && regionSelected("9")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_wien}
[end]

#Graz = 10
[regionSelected("10")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_graz}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_graz}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_graz}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_graz}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_graz}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_graz}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_graz}
[end]

[siteLanguage("languageId") == 1 && regionSelected("10")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_graz}
[end]

#Innsbruck = 11
[regionSelected("11")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_innsbruck}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_innsbruck}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_innsbruck}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_innsbruck}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_innsbruck}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_innsbruck}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_innsbruck}
[end]

[siteLanguage("languageId") == 1 && regionSelected("11")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_innsbruck}
[end]

#Mönchengladbach = 12
[regionSelected("12")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_moenchengladbach}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_moenchengladbach}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_moenchengladbach}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_moenchengladbach}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_moenchengladbach}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_moenchengladbach}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_moenchengladbach}
[end]

[siteLanguage("languageId") == 1 && regionSelected("12")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_moenchengladbach}
[end]

#Hamburg = 13
[regionSelected("13")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_hamburg}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_hamburg}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_hamburg}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_hamburg}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_hamburg}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_hamburg}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_hamburg}
[end]

[siteLanguage("languageId") == 1 && regionSelected("13")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_hamburg}
[end]

#Pockau = 14
[regionSelected("14")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_pockau}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_pockau}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_pockau}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_pockau}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_pockau}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_pockau}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_pockau}
[end]

[siteLanguage("languageId") == 1 && regionSelected("14")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_pockau}
[end]

#Augsburg = 44
[regionSelected("44")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_augsburg}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_augsburg}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_augsburg}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_augsburg}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_augsburg}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_augsburg}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_augsburg}
[end]

[siteLanguage("languageId") == 1 && regionSelected("44")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_augsburg}
[end]

#Intern = 15
[regionSelected("15")]
	plugin.tx_powermail.settings.setup.receiver.subject = {$allgem_anfragen_subjectAdmin_international}
	plugin.tx_powermail.settings.setup.receiver.email = {$allgem_anfragen_empfaenger_international}
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_international}
	plugin.tx_powermail.settings.setup.sender.email = {$allgem_anfragen_senderEmail_international}
	plugin.tx_powermail.settings.setup.sender.name = {$allgem_anfragen_senderName_international}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = {$allgem_anfragen_senderEmail_international}
	plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = {$allgem_anfragen_senderName_international}
[end]

[siteLanguage("languageId") == 1 && regionSelected("15")]
	plugin.tx_powermail.settings.setup.sender.subject = {$allgem_anfragen_subject_EN_international}
[end]


# plugin.tx_powermail.settings.setup.receiver.default.senderName.value = Labor Strauss Gruppe 1
# plugin.tx_powermail.settings.setup.receiver.default.senderEmail.value = office@lst.at

# plugin.tx_powermail.settings.setup.receiver.senderName = Labor Strauss Gruppe 2
# plugin.tx_powermail.settings.setup.receiver.senderEmail = office@lst.at

# plugin.tx_powermail.settings.setup.receiver.overwrite.senderEmail.value = office@lst.at
# plugin.tx_powermail.settings.setup.receiver.overwrite.senderName.value = Labor Strauss Gruppe 3

# plugin.tx_powermail.settings.setup.receiver.senderHeader.name.value = Labor Strauss Gruppe 4
# plugin.tx_powermail.settings.setup.receiver.senderHeader.email.value = office@lst.at