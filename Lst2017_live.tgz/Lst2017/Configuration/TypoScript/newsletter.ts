﻿tt_content.stdWrap {
# dataWrap = <a id="c{field:uid}"></a><div id="cd{field:uid}" class="container1">|</div>
}
styles.content {
   textStyle.altWrap = <p class="bodytext">|</p>
}

config {
  disablePrefixComment = 0
  locale_all = de_DE.UTF-8
  sys_language_uid = 0
  language = de
  locale_all = de_DE
  removeDefaultJS = 1
  additionalHeaders = Content-Type:text/html;charset=utf-8
  doctypeSwitch=1
  htmlTag_langKey = de-DE
  htmlTag_setParams = xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de"
  xhtml_cleaning = all
  doctype = xhtml_trans
  xmlprologue = none
  absRefPrefix = http://www.laborstrauss.com/
  baseURL = 0
}

tt_content.textmedia < tt_content.textpic
tt_content.textmedia.20.imgList.cObject.references.fieldName = assets

page = PAGE
page {
	 meta.robots = noindex, nofollow
     typeNum = 0
     bodyTag>
     config.disableAllHeaderCode = 1
     config.typolinkCheckRootline_noExtTarget = 1
     config.inlineStyle2TempFile = 0
	 config.index_enable = 0
	 
     10 = USER
     10.userFunc = tx_css2inline_pi1->main

     10.css = COA
     10.css.10 = FILE
     10.css.10.file = fileadmin/Lst2017/Resources/Public/StyleSheets/newsletter.css

     # Pseudoselektoren müssen trotzdem irgendwie inline definiert werden (head oder body möglich)
     
#	10 = COA
   
     10.html.10 = TEXT
     10.html.10.wrap (
         <head>
         <link rel="stylesheet" type="text/css" href="fileadmin/Lst2017/Resources/Public/StyleSheets/newsletter.css" media="all" />
        <style type="text/css">
         a:hover { }
         a:link { }
         a:visited {}

         </style>|</head>
  
     )
     10.html.10.value =<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 10.html.11.value = <meta name="robots" content="noindex, nofollow">
     10.html.20 = TEMPLATE
     10.html.20.wrap =<body|</td></tr></table></body>
     10.html.20.template = FILE
     10.html.20.template.file = fileadmin/Lst2017/Resources/Private/Templates/newsletter.html
     10.html.20.workOnSubpart = DOCUMENT

     10.html.20.marks.MENU<temp.menue
     10.html.20.marks.INHALT<styles.content.get
  
 

	10.html.20.marks.KORREKTEANZEIGENEWSLETTER = TEXT
	10.html.20.marks.KORREKTEANZEIGENEWSLETTER.value = Newsletter im Webbrowser anzeigen 
	10.html.20.marks.KORREKTEANZEIGENEWSLETTER.wrap = <a href="#"> | </a>
	10.html.20.marks.KORREKTEANZEIGENEWSLETTER.typolink.parameter.data=field:uid
	10.html.20.marks.KORREKTEANZEIGENEWSLETTER.typolink.additionalParams=&type=html&user_uid=###USER_uid###&user_email=###USER_email###&sys_authcode=###SYS_AUTHCODE###
	
	10.html.20.marks.SOCIAL_FACEBOOK = TEXT
	10.html.20.marks.SOCIAL_FACEBOOK.value (
		<a href="https://www.facebook.com/LaborStraussGruppe" target="_blank">
			<img class="image-embed-item" src="https://www.lst.at/fileadmin/Lst2017/Resources/Public/Images/social_facebook.png" alt="" width="33" height="32">
		</a>
	)
	10.html.20.marks.SOCIAL_LINKEDIN = TEXT
	10.html.20.marks.SOCIAL_LINKEDIN.value (
		<a href="https://www.linkedin.com/company/labor-strauss-firmengruppe" target="_blank">
			<img class="image-embed-item" src="https://www.lst.at/fileadmin/Lst2017/Resources/Public/Images/social_linked.png" alt="" width="33" height="32">
		</a>
	)
	10.html.20.marks.SOCIAL_XING = TEXT
	10.html.20.marks.SOCIAL_XING.value (
		<a href="http://xing.com/companies/laborstraussgruppe" target="_blank">
			<img class="image-embed-item" src="https://www.lst.at/fileadmin/Lst2017/Resources/Public/Images/social_xing.png" alt="" width="33" height="32">
		</a>
	)
	10.html.20.marks.SOCIAL_YOUTUBE = TEXT
	10.html.20.marks.SOCIAL_YOUTUBE.value (
		<a href="https://www.youtube.com/channel/UCIsrtPmJlEgFjm2pQwx-m_A" target="_blank">
			<img class="image-embed-item" src="https://www.lst.at/fileadmin/user_upload/social_youtube2.png" alt="" width="33" height="32">
		</a>
	)
	
	

	10.html.20.marks.NEWSLETTERLOGO = TEXT
	10.html.20.marks.NEWSLETTERLOGO.value (
		<a href="https://www.laborstrauss.com/"><img id="brand" width="149" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/lst-gruppe_de_2021.png"></a>
	)

	10.html.20.marks.FOOTERLOGO = TEXT
	10.html.20.marks.FOOTERLOGO.value (
		<a href="https://www.laborstrauss.com/"><img id="brand" width="101" height="58" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/newsl_footerlstlogo_2.png"></a>
	)
	
	10.html.20.marks.FOOTERMEPLOGO = TEXT
	10.html.20.marks.FOOTERMEPLOGO.value (
		<a href="https://www.mep-pockau.de/"><img id="brand" width="101" height="58" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/newsl_footermeplogo.png"></a>
	)
	
	
	10.html.20.marks.NEWLETTERSIGNOUT = TEXT
	10.html.20.marks.NEWLETTERSIGNOUT.value =  Möchten Sie den LST-Newsletter nicht mehr erhalten, klicken Sie bitte 
	
	10.html.20.marks.NEWLETTERSIGNOUT2 = TEXT
	10.html.20.marks.NEWLETTERSIGNOUT2.value =  <a href="https://www.laborstrauss.com/index.php?id=112###USER_fax###&tx_sremailsubscribe_pi1%5BrU%5D=###USER_uid###&tx_sremailsubscribe_pi1[fetch]=###USER_email###&tx_sremailsubscribe_pi1%5BsFK%5D=DELETE&tx_sremailsubscribe_pi1%5BaC%5D=###SYS_AUTHCODE###&tx_sremailsubscribe_pi1%5Bcmd%5D=infomail&fD%5B_FIELDLIST%5D=uid">hier zur Abmeldung</a>.

	#10.html.20.marks.NEWLETTERSIGNOUT2 = COA
	#10.html.20.marks.NEWLETTERSIGNOUT2 {
	#	10 = TEXT
	#  10.data = GP:user_uid
	#  10.noTrimWrap = |<a href="https://www.laborstrauss.com/index.php?id=112&tx_sremailsubscribe_pi1%5BrU%5D=||
	#  20 = TEXT
	#  20.data = GP:user_email
	#  20.noTrimWrap = |&tx_sremailsubscribe_pi1[fetch]=||
	#  30 = TEXT
	#  30.data = GP:sys_authcode
	#  30.noTrimWrap = |&tx_sremailsubscribe_pi1%5BsFK%5D=DELETE&tx_sremailsubscribe_pi1%5BaC%5D=||
	#  40 = TEXT
	#  40.noTrimWrap = |&tx_sremailsubscribe_pi1%5Bcmd%5D=infomail&fD%5B_FIELDLIST%5D=uid">hier zur Abmeldung</a>|
	#}


	10.html.20.marks.FOOTERSITENAME = TEXT
	10.html.20.marks.FOOTERSITENAME.value = Labor Strauss Gruppe


	10.html.20.marks.FOOTERSITEIMPRESSUM = TEXT
	10.html.20.marks.FOOTERSITEIMPRESSUM.value = <a href="https://www.laborstrauss.com/impressum/">Impressum & Datenschutz</a>
	
	10.html.20.marks.PAGETITLE = TEXT
	10.html.20.marks.PAGETITLE.data = page : title
	10.html.20.marks.SEITENTITEL.field = nav_title // title
	  
	10.html.20.marks.INHALT < styles.content.get
	10.html.20.marks.INHALTNEU2 < styles.content.get
	
	10.html.20.marks.EINLEITUNGINHALT < styles.content.get
	10.html.20.marks.EINLEITUNGINHALT {
				select.where = colPos = 1
	}

    
}


##  Newsletter en
[336 in tree.rootLineIds]

page.10.html.20.marks.KORREKTEANZEIGENEWSLETTER.value = Display newsletter in webbrowser.
page.10.html.20.marks.NEWSLETTERLOGO = TEXT
page.10.html.20.marks.NEWSLETTERLOGO.value (
		<a href="https://www.laborstrauss.com/en/?fL=1"><img id="brand" width="149" border="0" title="LST-Group" alt="LST-Group" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/lst-gruppe-en_2021.png"></a>
	)
page.10.html.20.marks.NEWLETTERSIGNOUT.value = If you no longer wish to receive the LST newsletter, please click
# page.10.html.20.marks.NEWLETTERSIGNOUT2.value =  <a href="https://www.laborstrauss.com/news/newsletter/edit/?L=1&fL=1&tx_sremailsubscribe_pi1%5BrU%5D=&cHash=030c2b07062da76bd6650019a841e14c">here</a>.

page.10.html.20.marks.NEWLETTERSIGNOUT2.value =  <a href="https://www.laborstrauss.com/index.php?id=112###USER_fax###&L=1&fL=1&tx_sremailsubscribe_pi1%5BrU%5D=###USER_uid###&tx_sremailsubscribe_pi1[fetch]=###USER_email###&tx_sremailsubscribe_pi1%5BsFK%5D=DELETE&tx_sremailsubscribe_pi1%5BaC%5D=###SYS_AUTHCODE###&tx_sremailsubscribe_pi1%5Bcmd%5D=infomail&fD%5B_FIELDLIST%5D=uid">here</a>.

page.10.html.20.marks.FOOTERSITENAME.value = Labor Strauss Group
page.10.html.20.marks.FOOTERSITEIMPRESSUM.value = <a href="https://www.laborstrauss.com/en/legal-notice/">Legal notice & Privacy</a>

page.10.html.20.marks.FOOTERLOGO = TEXT
page.10.html.20.marks.FOOTERLOGO.value (
		<a href="https://www.laborstrauss.com/"><img id="brand" width="101" height="58" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/newsl_footerlstlogo_en_2.png"></a>
	)

[end]

## Marketing Newsletter deutsch
[388 in tree.rootLineIds]
page.10.html.20.marks.NEWLETTERSIGNOUT2.value = 
page.10.html.20.marks.NEWLETTERSIGNOUT.value =  Diesen Newsletter erhalten Sie, weil Sie sich für den LST-Downloadbereich und den Empfang der Bulletins registriert haben. Möchten Sie den Marketing Newsletter nicht mehr erhalten, senden Sie einfach eine kurze Nachricht an <a href="mailto:office@lst.at">office@lst.at</a>.
[end]

## Marketing Newsletter english
[389 in tree.rootLineIds]
page.10.html.20.marks.NEWLETTERSIGNOUT2.value =
page.10.html.20.marks.NEWLETTERSIGNOUT.value =  You receive this newsletter because you have registered for the LST download area and the receipt of the Bulletins. If you no longer wish to receive the Marketing Bulletin, just send a short message to <a href="mailto:office@lst.at">office@lst.at</a>.
page.10.html.20.marks.KORREKTEANZEIGENEWSLETTER.value = If this email is not displayed correctly, please click here.
page.10.html.20.marks.NEWSLETTERLOGO = TEXT
page.10.html.20.marks.NEWSLETTERLOGO.value (
		<a href="https://www.laborstrauss.com/en/?fL=1"><img id="brand" width="149" border="0" title="LST-Group" alt="LST-Group" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/lst-gruppe-en_2021.png"></a>
	)
page.10.html.20.marks.FOOTERSITENAME.value = Labor Strauss Group
page.10.html.20.marks.FOOTERSITEIMPRESSUM.value = <a href="https://www.laborstrauss.com/en/legal-notice/">Legal notice & Privacy</a>

page.10.html.20.marks.FOOTERLOGO = TEXT
page.10.html.20.marks.FOOTERLOGO.value (
		<a href="https://www.laborstrauss.com/"><img id="brand" width="101" height="58" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/newsl_footerlstlogo_en_2.png"></a>
	)
[end]

## Technischer Newsletter deutsch
[390 in tree.rootLineIds]
page.10.html.20.marks.NEWLETTERSIGNOUT2.value = 
page.10.html.20.marks.NEWLETTERSIGNOUT.value =
[end]

## Technischer Newsletter english
[391 in tree.rootLineIds]
page.10.html.20.marks.NEWLETTERSIGNOUT2.value = 
page.10.html.20.marks.NEWLETTERSIGNOUT.value =
page.10.html.20.marks.KORREKTEANZEIGENEWSLETTER.value = If this email is not displayed correctly, please click here.
page.10.html.20.marks.NEWSLETTERLOGO = TEXT
page.10.html.20.marks.NEWSLETTERLOGO.value (
		<a href="https://www.laborstrauss.com/en/?fL=1"><img id="brand" width="149" border="0" title="LST-Group" alt="LST-Group" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/lst-gruppe-en.png"></a>
	)
page.10.html.20.marks.FOOTERSITENAME.value = Labor Strauss Group
page.10.html.20.marks.FOOTERSITEIMPRESSUM.value = <a href="https://www.laborstrauss.com/en/legal-notice/">Legal notice & Privacy</a>

page.10.html.20.marks.FOOTERLOGO = TEXT
page.10.html.20.marks.FOOTERLOGO.value (
		<a href="https://www.laborstrauss.com/"><img id="brand" width="101" height="58" border="0" title="Labor Strauss Gruppe" alt="Labor Strauss Gruppe" src="http://www.laborstrauss.com/fileadmin/Lst2017/Resources/Public/Images/newsl_footerlstlogo_en_2.png"></a>
	)
[end]


page_nurtext < page
page_nurtext.typeNum = 99

page{  
  headerData {
    10 = TEXT
    10.value (
      <style type="text/css">
    body{font-family:Arial,Helvetica;font-size:100%;}
    body{background-color:  #ccbcaf;
   background-position:center top;
   background-repeat:repeat-x;
      padding-top:0px;margin-top:0px;
   }
    .container_12 ,.container_12 .grid_12 {
  width: 980px;
}

div.header_logo{padding-top:8px;}
     </style>
   )
  }
}
config.language=de
config.locale_all = de_DE
page.config.language=de
page.config.locale_all = de_DE
page.config.index_enable = 0

config {
removeDefaultJS = 1
additionalHeaders = Content-Type:text/html;charset=utf-8
doctypeSwitch=1
htmlTag_langKey = de-DE

htmlTag_setParams = xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de"
  xhtml_cleaning = all

  doctype = xhtml_trans
  
  xmlprologue = none
#spamProtectEmailAddresses = 6
#spamProtectEmailAddresses_atSubst = <span>&#064;</span>

}

plugin.tx_directmail_pi1 = USER
plugin.tx_directmail_pi1.userFunc = tx_directmail_pi1->main
plugin.tx_directmail_pi1 {
  siteUrl = {$plugin.tx_directmail_pi1.siteUrl}
  flowedFormat = {$plugin.tx_directmail_pi1.flowedFormat}
  header.defaultType = 1
  header.date = D-m-Y
  header.datePrefix = |###HEADER_DATE_PREFIX### |
  header.linkPrefix = | ###HEADER_LINK_PREFIX### |
  header.1.preLineLen = 76
  header.1.postLineLen = 76
  header.1.preBlanks=1
  header.1.stdWrap.case = upper
  header.2 < .header.1
  header.2.preLineChar=*
  header.2.postLineChar=*
  header.3.preBlanks=2
  header.3.postBlanks=1
  header.3.stdWrap.case = upper
  

  header.4 < .header.1
  header.4.preLineChar= =
  header.4.postLineChar= =
  header.4.preLineBlanks= 1
  header.4.postLineBlanks= 1
  header.5.removeSplitChar = {$plugin.tx_directmail_pi1.removeSplitChar}
  header.5.preBlanks=1
  header.5.autonumber=1
  header.5.prefix = |: >> |
  defaultOutput (
|
[###UNRENDERED_CONTENT### ###CType### ]
|
  )

  uploads.header = |###UPLOADS_HEADER###|
  images.header = |###IMAGES_HEADER###|
  images.linkPrefix = | ###IMAGE_LINK_PREFIX### |
  images.captionHeader = |###CAPTION_HEADER###|

  bulletlist.0.bullet = |*  |
  bulletlist.1.bullet = |#  |
  bulletlist.2.bullet = | - |
  bulletlist.3.bullet = |>  |
  bulletlist.3.secondRow = |.  |
  bulletlist.3.blanks = 1

  menu =< tt_content.menu.20

  shortcut =< tt_content.shortcut.20
  shortcut.0.conf.tt_content =< plugin.tx_directmail_pi1
  shortcut.0.tables = tt_content

  bodytext.doubleLF = {$plugin.tx_directmail_pi1.doubleLF}
  bodytext.stdWrap.parseFunc.tags {
    link =< lib.parseFunc_RTE.tags.link
    typolist = USER
    typolist.userFunc = tx_directmail_pi1->typolist
    typolist.siteUrl = {$plugin.tx_directmail_pi1.siteUrl}
    typolist.bulletlist =< plugin.tx_directmail_pi1.bulletlist
    typohead = USER
    typohead.userFunc = tx_directmail_pi1->typohead
    typohead.siteUrl = {$plugin.tx_directmail_pi1.siteUrl}
    typohead.header =< plugin.tx_directmail_pi1.header
    typocode = USER
    typocode.userFunc = tx_directmail_pi1->typocode
    typocode.siteUrl = {$plugin.tx_directmail_pi1.siteUrl}
  }
}

includeLibs.tx_directmail_pi1 = EXT:direct_mail/pi1/class.tx_directmail_pi1.php

tx_directmail_pi1 >
tx_directmail_pi1 = PAGE
tx_directmail_pi1.typeNum=99
tx_directmail_pi1.config {
  disableAllHeaderCode = 1
  additionalHeaders = Content-type:text/plain
}

tx_directmail_pi1.10 = TEMPLATE

tx_directmail_pi1.10 {
  template = FILE
  template.file = fileadmin/Lst2017/Resources/Private/Templates/newsletter_plain.tmpl
  marks.CONTENT < styles.content.get
  marks.CONTENT.renderObj = < plugin.tx_directmail_pi1
  marks.DATE = TEXT
  marks.DATE.data = date:U
  marks.DATE.strftime = %e. %B %Y
}

config.insertDmailerBoundaries = 1

    // Configuring the insertion of dmailer boundaries
    includeLibs.tx_directmail_container = EXT:direct_mail/res/scripts/class.tx_directmail_container.php   
    // In html content
    tt_content.stdWrap.postUserFunc = tx_directmail_container->insert_dMailer_boundaries   
    // In old plaintext content static tenmplate
    lib.alt_plaintext.renderObj.userProc < tt_content.stdWrap.postUserFunc
    lib.alt_plaintext.renderObj.userProc.useParentCObj = 1   
    // In new direct mail plain text plugin
    plugin.tx_directmail_pi1.userProc < tt_content.stdWrap.postUserFunc
    plugin.tx_directmail_pi1.userProc.useParentCObj = 1   
    // Enable the insertion of content boundaries
    config.insertDmailerBoundaries = 1


 tt_content.image.20 {
   imageStdWrap.dataWrap = <div class="csc-textpic-imagewrap" style="width:{register:totalwidth}px;"> | </div>
   imageStdWrapNoWidth.wrap = <div class="csc-textpic-imagewrap"> | </div>
   layout {
     17 = TEXT
    17 {
      value = <table class="csc-textpic csc-textpic-intext-right###CLASSES###"><tr><td valign="top">###TEXT###</td><td valign="top">###IMAGES###</td></tr></table>
      override = <div class="csc-textpic csc-textpic-responsive csc-textpic-intext-left###CLASSES###">###IMAGES######TEXT###</div>
      override {
        if {
          value = default
          equals = {$styles.content.imgtext.layoutKey}
          negate = 1
        }
      }
    }
    18 = TEXT
    18 {
      value = <table class="test csc-textpic csc-textpic-intext-left###CLASSES###" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###IMAGES###</td><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###TEXT###</td></tr></table>
      override = <div class="csc-textpic csc-textpic-responsive csc-textpic-intext-left###CLASSES###">###IMAGES######TEXT###</div>
      override {
        if {
          value = default
          equals = {$styles.content.imgtext.layoutKey}
          negate = 1
        }
      }
    }
    
    25 = TEXT
    25 {
      value = <table class="test csc-textpic-intext-right-nowrap###CLASSES###" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###TEXT###</td><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###IMAGES###</td></tr></table>
      override = <div class="csc-textpic csc-textpic-responsive csc-textpic-intext-left###CLASSES###">###IMAGES######TEXT###</div>
      override {
        if {
          value = default
          equals = {$styles.content.imgtext.layoutKey}
          negate = 1
        }
      }
    }
    
    26 = TEXT
    26 {
      value = <table class="test csc-textpic-intext-left-nowrap###CLASSES###" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###IMAGES###</td><td valign="top" class="mso-table-lspace: 0pt;mso-table-rspace: 0pt;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;">###TEXT###</td></tr></table>
      override = <div class="csc-textpic csc-textpic-responsive csc-textpic-intext-left###CLASSES###">###IMAGES######TEXT###</div>
      override {
        if {
          value = default
          equals = {$styles.content.imgtext.layoutKey}
          negate = 1
        }
      }
    }
    
  }
}



#plugin.tx_directmail_pi1.siteUrl = http://www.laborstrauss.com/

# Cache deaktivieren

# config.no_cache = 1
# page.config.no_cache = 1