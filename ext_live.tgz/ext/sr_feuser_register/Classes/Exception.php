<?php
namespace SJBR\SrFeuserRegister;

/*
 *  Copyright notice
 *
 *  (c) 2015-2025 Stanislas Rolland <typo3AAAA(arobas)sjbr.ca>
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 */

/**
 * An exception
 */

class Exception extends \Exception
{
	/**
	 * Exception codes
	 */
	const MISSING_SUBPART = 1;
	const MISCONFIGURATION = 2;
	const TABLE_NOT_DEFINED = 3;
	const ADMIN_EMAIL_UNROUTABLE = 4;
	const OPENSSL_NOT_INSTALLED = 5;
}